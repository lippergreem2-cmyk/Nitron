"""Nitron generated Python module."""
