package com.nitron.bubble

import android.Manifest
import android.animation.ObjectAnimator
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.nitron.bubble.chat.ChatHistoryStore
import com.nitron.bubble.chat.ChatManager
import com.nitron.bubble.chat.Message
import java.util.Locale

class VoiceModeActivity : AppCompatActivity() {

    private lateinit var chatManager: ChatManager
    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var tts: TextToSpeech

    private lateinit var replyFrame: FrameLayout
    private lateinit var replyText: TextView
    private lateinit var micIcon: TextView

    private val handler = Handler(Looper.getMainLooper())

    private var isListening = false
    private var voiceModeActive = true
    private var userStopped = false

    private var ttsReady = false
    private var isNitronSpeaking = false

    private var recognizerStarting = false
    private var lastRecognizedText = ""

    private val micPermissionRequestCode = 501

    private val restartRunnable = Runnable {
        if (
            !isFinishing &&
            voiceModeActive &&
            !userStopped &&
            !isListening &&
            !isNitronSpeaking
        ) {
            startListening()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_voice_mode)

        ChatHistoryStore.init(this)

        replyFrame = findViewById(R.id.voiceReplyFrame)
        replyText = findViewById(R.id.voiceReplyText)
        micIcon = findViewById(R.id.voiceMicIcon)

        chatManager = ChatManager()

        chatManager.setListener(object : ChatManager.ChatListener {

            override fun onReply(reply: String) {
                runOnUiThread {

                    replyFrame.visibility = View.VISIBLE
                    replyText.text = reply

                    ChatHistoryStore.add(
                        Message(reply, false)
                    )

                    speak(reply)
                }
            }
        })

        tts = TextToSpeech(this) { status ->

            if (status == TextToSpeech.SUCCESS) {

                val result = tts.setLanguage(Locale.getDefault())

                ttsReady =
                    result != TextToSpeech.LANG_MISSING_DATA &&
                    result != TextToSpeech.LANG_NOT_SUPPORTED

                tts.setOnUtteranceProgressListener(
                    object : UtteranceProgressListener() {

                        override fun onStart(utteranceId: String?) {
                            runOnUiThread {
                                isNitronSpeaking = true
                            }
                        }

                        override fun onDone(utteranceId: String?) {
                            runOnUiThread {

                                isNitronSpeaking = false

                                /*
                                 * Do not immediately reopen the microphone.
                                 * Give Android audio routing a moment to settle.
                                 */
                                scheduleListening(700)
                            }
                        }

                        override fun onError(utteranceId: String?) {
                            runOnUiThread {

                                isNitronSpeaking = false

                                scheduleListening(700)
                            }
                        }
                    }
                )
            }
        }

        setupSpeechRecognizer()
        startOrbitAnimations()
        setupOrbDragRotation()
        makeOrbTextHollow()

        /*
         * The bubble itself starts voice mode.
         * The microphone button is NOT required.
         */
        window.decorView.postDelayed({

            if (!isFinishing && voiceModeActive) {
                requestMicAndListen()
            }

        }, 500)

        /*
         * Microphone icon is now only a manual
         * stop/start control. Voice mode itself is automatic.
         */
        micIcon.setOnClickListener {

            if (isListening) {

                userStopped = true
                voiceModeActive = false

                try {
                    speechRecognizer.stopListening()
                } catch (_: Exception) {
                }

                isListening = false
                micIcon.alpha = 1.0f

            } else {

                userStopped = false
                voiceModeActive = true

                requestMicAndListen()
            }
        }

        findViewById<TextView>(R.id.voiceCloseIcon).setOnClickListener {
            finish()
        }

        findViewById<TextView>(R.id.voiceMenuIcon).setOnClickListener {

            val panel =
                findViewById<View>(R.id.voiceActionPanel)

            panel.visibility =
                if (panel.visibility == View.VISIBLE) {
                    View.GONE
                } else {
                    View.VISIBLE
                }
        }

        findViewById<TextView>(R.id.actionTalk).setOnClickListener {

            userStopped = false
            voiceModeActive = true

            if (!isListening) {
                requestMicAndListen()
            }
        }

        findViewById<TextView>(R.id.actionSettings).setOnClickListener {
            startActivity(
                Intent(this, SettingsActivity::class.java)
            )
        }

        findViewById<TextView>(R.id.actionScreenshot).setOnClickListener {
            Toast.makeText(
                this,
                "Screenshot: coming soon",
                Toast.LENGTH_SHORT
            ).show()
        }

        findViewById<TextView>(R.id.actionApps).setOnClickListener {
            startActivity(
                Intent(this, AppsListActivity::class.java)
            )
        }

        findViewById<TextView>(R.id.actionQR).setOnClickListener {
            Toast.makeText(
                this,
                "QR Scan: coming soon",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun startOrbitAnimations() {

        val ring1 =
            findViewById<View>(R.id.orbitRing1)

        val ring2 =
            findViewById<View>(R.id.orbitRing2)

        val anim1 =
            ObjectAnimator.ofFloat(
                ring1,
                "rotation",
                ring1.rotation,
                ring1.rotation + 360f
            )

        anim1.duration = 9000
        anim1.repeatCount = ObjectAnimator.INFINITE
        anim1.interpolator = LinearInterpolator()
        anim1.start()

        val anim2 =
            ObjectAnimator.ofFloat(
                ring2,
                "rotation",
                ring2.rotation,
                ring2.rotation - 360f
            )

        anim2.duration = 13000
        anim2.repeatCount = ObjectAnimator.INFINITE
        anim2.interpolator = LinearInterpolator()
        anim2.start()
    }

    private fun makeOrbTextHollow() {

        val orbText =
            findViewById<TextView>(R.id.voiceOrbText)

        orbText.setLayerType(
            View.LAYER_TYPE_SOFTWARE,
            orbText.paint
        )

        orbText.paint.style =
            android.graphics.Paint.Style.STROKE

        orbText.paint.strokeWidth =
            1.3f * resources.displayMetrics.density

        orbText.invalidate()
    }

    private fun setupOrbDragRotation() {
        val orb = findViewById<View>(R.id.voiceOrbContainer)

        orb.cameraDistance =
            12000 * resources.displayMetrics.density

        var lastX = 0f
        var lastY = 0f
        var downX = 0f
        var downY = 0f

        orb.setOnTouchListener { view, event ->

            when (event.actionMasked) {

                MotionEvent.ACTION_DOWN -> {
                    lastX = event.rawX
                    lastY = event.rawY
                    downX = event.rawX
                    downY = event.rawY
                    true
                }

                MotionEvent.ACTION_MOVE -> {

                    val dx = event.rawX - lastX
                    val dy = event.rawY - lastY

                    view.rotationY += dx * 0.4f

                    val newRotationX =
                        (
                            view.rotationX -
                            dy * 0.4f
                        ).coerceIn(-60f, 60f)

                    view.rotationX = newRotationX

                    lastX = event.rawX
                    lastY = event.rawY

                    true
                }

                MotionEvent.ACTION_UP -> {

                    val totalX =
                        event.rawX - downX

                    val totalY =
                        event.rawY - downY

                    // Swipe DOWN = collapse voice interface
                    if (
                        totalY > 120f &&
                        kotlin.math.abs(totalY) >
                        kotlin.math.abs(totalX) * 1.3f
                    ) {
                        collapseVoiceMode()
                    }

                    true
                }

                else -> true
            }
        }
    }

    private fun collapseVoiceMode() {

        // Tell the floating bubble that the next tap
        // should open the normal chat.
        getSharedPreferences(
            "nitron_voice_state",
            MODE_PRIVATE
        )
            .edit()
            .putBoolean(
                "open_chat_on_bubble_tap",
                true
            )
            .apply()

        voiceModeActive = false
        userStopped = true

        try {
            speechRecognizer.cancel()
        } catch (_: Exception) {
        }

        try {
            tts.stop()
        } catch (_: Exception) {
        }

        isListening = false
        isNitronSpeaking = false

        // Small collapse animation.
        findViewById<View>(
            R.id.voiceOrbContainer
        ).animate()
            .scaleX(0.15f)
            .scaleY(0.15f)
            .alpha(0f)
            .setDuration(220)
            .withEndAction {
                finish()
            }
            .start()

        findViewById<View>(
            R.id.voiceGreeting
        ).animate()
            .alpha(0f)
            .setDuration(180)
            .start()

        findViewById<View>(
            R.id.voiceReplyFrame
        ).animate()
            .alpha(0f)
            .setDuration(180)
            .start()
    }

    private fun setupSpeechRecognizer() {

        speechRecognizer =
            SpeechRecognizer.createSpeechRecognizer(this)

        speechRecognizer.setRecognitionListener(
            object : RecognitionListener {

                override fun onReadyForSpeech(
                    params: Bundle?
                ) {
                    recognizerStarting = false
                    isListening = true

                    runOnUiThread {
                        micIcon.alpha = 0.5f
                    }
                }

                override fun onBeginningOfSpeech() {

                    /*
                     * BARGE-IN:
                     * If the user starts talking while
                     * Nitron is speaking, immediately stop TTS.
                     */
                    if (isNitronSpeaking) {
                        interruptNitron()
                    }
                }

                override fun onRmsChanged(
                    rmsdB: Float
                ) {
                }

                override fun onBufferReceived(
                    buffer: ByteArray?
                ) {
                }

                override fun onEndOfSpeech() {
                    /*
                     * Do not restart here.
                     * onResults/onError handles the session.
                     */
                }

                override fun onError(error: Int) {

                    recognizerStarting = false
                    isListening = false

                    runOnUiThread {
                        micIcon.alpha = 1.0f
                    }

                    /*
                     * Important:
                     * never hammer SpeechRecognizer with
                     * immediate restarts.
                     */
                    if (
                        voiceModeActive &&
                        !userStopped &&
                        !isFinishing
                    ) {
                        scheduleListening(1000)
                    }
                }

                override fun onResults(
                    results: Bundle?
                ) {

                    recognizerStarting = false
                    isListening = false

                    runOnUiThread {
                        micIcon.alpha = 1.0f
                    }

                    val matches =
                        results?.getStringArrayList(
                            SpeechRecognizer.RESULTS_RECOGNITION
                        )

                    val spokenText =
                        matches
                            ?.firstOrNull()
                            ?.trim()

                    if (!spokenText.isNullOrBlank()) {

                        /*
                         * Ignore an accidental duplicate result.
                         */
                        if (spokenText != lastRecognizedText) {

                            lastRecognizedText =
                                spokenText

                            ChatHistoryStore.add(
                                Message(
                                    spokenText,
                                    true
                                )
                            )

                            /*
                             * This is the actual path that
                             * sends the user's words to Nitron.
                             */
                            chatManager.sendMessage(
                                spokenText
                            )

                            /*
                             * Don't reopen the microphone
                             * immediately. ChatManager will
                             * call speak() when the reply arrives.
                             */
                        }
                    } else {

                        scheduleListening(700)
                    }
                }

                override fun onPartialResults(
                    partialResults: Bundle?
                ) {

                    val matches =
                        partialResults?.getStringArrayList(
                            SpeechRecognizer.RESULTS_RECOGNITION
                        )

                    val partial =
                        matches?.firstOrNull()?.trim()

                    if (!partial.isNullOrBlank()) {

                        /*
                         * Show what the user is saying.
                         */
                        runOnUiThread {

                            replyFrame.visibility =
                                View.VISIBLE

                            replyText.text =
                                partial
                        }

                        /*
                         * If Nitron is talking and the
                         * user starts speaking, stop TTS.
                         */
                        if (isNitronSpeaking) {
                            interruptNitron()
                        }
                    }
                }

                override fun onEvent(
                    eventType: Int,
                    params: Bundle?
                ) {
                }
            }
        )
    }

    private fun requestMicAndListen() {

        if (
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {

            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.RECORD_AUDIO
                ),
                micPermissionRequestCode
            )

            return
        }

        startListening()
    }

    private fun startListening() {

        if (
            isFinishing ||
            userStopped ||
            !voiceModeActive ||
            isListening ||
            recognizerStarting ||
            isNitronSpeaking
        ) {
            return
        }

        recognizerStarting = true

        val intent =
            Intent(
                RecognizerIntent.ACTION_RECOGNIZE_SPEECH
            )

        intent.putExtra(
            RecognizerIntent.EXTRA_LANGUAGE_MODEL,
            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
        )

        intent.putExtra(
            RecognizerIntent.EXTRA_LANGUAGE,
            Locale.getDefault()
        )

        intent.putExtra(
            RecognizerIntent.EXTRA_PARTIAL_RESULTS,
            true
        )

        /*
         * Give the user more time to speak naturally.
         * This also greatly reduces rapid recognizer
         * open/close cycles.
         */
        intent.putExtra(
            RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS,
            2200
        )

        intent.putExtra(
            RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS,
            1500
        )

        intent.putExtra(
            RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS,
            800
        )

        try {

            speechRecognizer.startListening(intent)

        } catch (_: Exception) {

            recognizerStarting = false
            isListening = false

            micIcon.alpha = 1.0f

            scheduleListening(1200)
        }
    }

    private fun scheduleListening(delay: Long) {

        handler.removeCallbacks(restartRunnable)

        if (
            isFinishing ||
            userStopped ||
            !voiceModeActive
        ) {
            return
        }

        handler.postDelayed(
            restartRunnable,
            delay
        )
    }

    private fun speak(text: String) {

        if (text.isBlank()) {
            scheduleListening(500)
            return
        }

        if (!ttsReady) {

            /*
             * TTS may still be initializing.
             * Try again shortly instead of losing the reply.
             */
            handler.postDelayed(
                {
                    if (!isFinishing) {
                        speak(text)
                    }
                },
                300
            )

            return
        }

        isNitronSpeaking = true

        /*
         * Make sure the recognizer isn't still holding
         * the microphone while TTS starts.
         */
        if (isListening) {

            try {
                speechRecognizer.stopListening()
            } catch (_: Exception) {
            }

            isListening = false
            recognizerStarting = false
        }

        tts.speak(
            text,
            TextToSpeech.QUEUE_FLUSH,
            null,
            "nitron_reply"
        )
    }

    private fun interruptNitron() {

        if (!isNitronSpeaking) {
            return
        }

        try {
            tts.stop()
        } catch (_: Exception) {
        }

        isNitronSpeaking = false

        /*
         * The recognizer should already be receiving the
         * user's speech. Do NOT start another recognizer
         * session here.
         */
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {

        super.onRequestPermissionsResult(
            requestCode,
            permissions,
            grantResults
        )

        if (
            requestCode == micPermissionRequestCode &&
            grantResults.isNotEmpty() &&
            grantResults[0] ==
            PackageManager.PERMISSION_GRANTED
        ) {

            userStopped = false
            voiceModeActive = true

            scheduleListening(300)
        }
    }

    override fun onDestroy() {

        voiceModeActive = false
        userStopped = true
        isNitronSpeaking = false

        handler.removeCallbacksAndMessages(null)

        try {
            speechRecognizer.cancel()
        } catch (_: Exception) {
        }

        try {
            speechRecognizer.destroy()
        } catch (_: Exception) {
        }

        try {
            tts.stop()
            tts.shutdown()
        } catch (_: Exception) {
        }

        super.onDestroy()
    }
}
