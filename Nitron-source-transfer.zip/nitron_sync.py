#!/usr/bin/env python3

from pathlib import Path
import hashlib
import json
import time
import uuid

ROOT = Path(__file__).resolve().parent
STATE_DIR = ROOT / ".nitron_sync"
MANIFEST_FILE = STATE_DIR / "manifest.json"
DEVICE_FILE = STATE_DIR / "device.json"

EXCLUDED_DIRS = {
    ".git",
    ".gradle",
    ".idea",
    "__pycache__",
    "build",
    ".nitron_sync",
}

EXCLUDED_FILES = {
    "Nitron-source-transfer.zip",
    "Nitron-transfer.zip",
    ".env",
}

SECRET_NAMES = {
    "google-services.json",
    "nitron-release.jks",
}

def sha256(path):
    digest = hashlib.sha256()

    with path.open("rb") as file:
        for chunk in iter(
            lambda: file.read(1024 * 1024),
            b""
        ):
            digest.update(chunk)

    return digest.hexdigest()


def should_include(path):
    relative = path.relative_to(ROOT)

    if path.name in EXCLUDED_FILES:
        return False

    if path.name in SECRET_NAMES:
        return False

    if any(
        part in EXCLUDED_DIRS
        for part in relative.parts
    ):
        return False

    # Don't index likely secret environment files.
    if path.suffix in {".keystore", ".jks"}:
        return False

    return path.is_file()


def ensure_state():
    STATE_DIR.mkdir(
        parents=True,
        exist_ok=True
    )


def get_device_id():
    ensure_state()

    if DEVICE_FILE.exists():
        data = json.loads(
            DEVICE_FILE.read_text()
        )

        return data["device_id"]

    device_id = str(uuid.uuid4())

    data = {
        "device_id": device_id,
        "created_at": int(time.time())
    }

    DEVICE_FILE.write_text(
        json.dumps(
            data,
            indent=2
        )
    )

    return device_id


def build_manifest():
    ensure_state()

    device_id = get_device_id()

    project_file = STATE_DIR / "project.json"

    if project_file.exists():
        project_data = json.loads(
            project_file.read_text()
        )
        project_id = project_data["project_id"]
    else:
        raise RuntimeError(
            "Nitron project identity is missing."
        )

    files = {}

    for path in ROOT.rglob("*"):

        if not should_include(path):
            continue

        relative = str(
            path.relative_to(ROOT)
        )

        files[relative] = {
            "size": path.stat().st_size,
            "sha256": sha256(path)
        }

    manifest = {
        "name": "Nitron",
        "protocol_version": 1,
        "project_id": project_id,
        "device_id": device_id,
        "generated_at": int(time.time()),
        "files": files
    }

    MANIFEST_FILE.write_text(
        json.dumps(
            manifest,
            indent=2,
            sort_keys=True
        )
    )

    return manifest


def main():
    manifest = build_manifest()

    print()
    print("========================================")
    print(" Nitron Sync Manifest")
    print("========================================")
    print()
    print("Device ID:")
    print(manifest["device_id"])
    print()
    print("Tracked files:")
    print(len(manifest["files"]))
    print()
    print("Manifest:")
    print(MANIFEST_FILE)
    print()




def compare_manifests(local_manifest, remote_manifest):
    local_files = local_manifest.get("files", {})
    remote_files = remote_manifest.get("files", {})

    local_paths = set(local_files)
    remote_paths = set(remote_files)

    added = sorted(
        remote_paths - local_paths
    )

    deleted = sorted(
        local_paths - remote_paths
    )

    modified = sorted(
        path
        for path in local_paths & remote_paths
        if local_files[path]["sha256"]
        != remote_files[path]["sha256"]
    )

    unchanged = sorted(
        path
        for path in local_paths & remote_paths
        if local_files[path]["sha256"]
        == remote_files[path]["sha256"]
    )

    return {
        "added": added,
        "modified": modified,
        "deleted": deleted,
        "unchanged": unchanged
    }


def compare_with_manifest(path):
    local_manifest = build_manifest()

    remote_path = Path(path)

    if not remote_path.exists():
        raise FileNotFoundError(
            f"Manifest not found: {remote_path}"
        )

    remote_manifest = json.loads(
        remote_path.read_text()
    )

    if remote_manifest.get("name") != "Nitron":
        raise ValueError(
            "The selected manifest is not a Nitron manifest."
        )

    local_project_id = local_manifest.get("project_id")
    remote_project_id = remote_manifest.get("project_id")

    if not local_project_id:
        raise ValueError(
            "This Nitron copy has no project ID."
        )

    if not remote_project_id:
        raise ValueError(
            "The remote Nitron copy has no project ID."
        )

    if local_project_id != remote_project_id:
        raise ValueError(
            "The two Nitron copies belong to different projects."
        )

    if (
        remote_manifest.get("device_id")
        == local_manifest.get("device_id")
    ):
        raise ValueError(
            "The selected manifest belongs to this Nitron copy."
        )

    result = compare_manifests(
        local_manifest,
        remote_manifest
    )

    print()
    print("========================================")
    print(" Nitron Sync Comparison")
    print("========================================")
    print()

    print(f"New on remote: {len(result['added'])}")
    print(f"Modified:      {len(result['modified'])}")
    print(f"Deleted:       {len(result['deleted'])}")
    print(f"Unchanged:     {len(result['unchanged'])}")
    print()

    if result["added"]:
        print("NEW:")
        for path in result["added"]:
            print(f"  + {path}")

    if result["modified"]:
        print()
        print("MODIFIED:")
        for path in result["modified"]:
            print(f"  ~ {path}")

    if result["deleted"]:
        print()
        print("DELETED:")
        for path in result["deleted"]:
            print(f"  - {path}")

    return result


if __name__ == "__main__":
    import sys

    if len(sys.argv) == 1:
        main()

    elif sys.argv[1] == "compare":

        if len(sys.argv) != 3:
            print(
                "Usage: python nitron_sync.py compare <manifest.json>"
            )
            raise SystemExit(1)

        compare_with_manifest(sys.argv[2])

    else:
        print(
            "Usage:"
        )
        print(
            "  python nitron_sync.py"
        )
        print(
            "  python nitron_sync.py compare <manifest.json>"
        )

# Nitron sync test

