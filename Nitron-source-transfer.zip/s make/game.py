
print("Nitron Game")
